
import React from 'react';
import './About.css';

const About = () => {
  return (
    <div className="container">
      <div className="page-content">
        <h1>About Us</h1>
        <p>Learn more about our website.</p>
      </div>
    </div>
  );
};

export default About;
